**Description**

This resource will apply permissions to a user profile service application. 
These can control access to create my sites, use social features, and use 
tagging. If you want to allow all users the ability to use a specific 
permisisons include "Everyone" as a user in the corresponding property. To 
specify that there should be no permissions on a type, use "none"
