**Description**

This resource will create a section in a user profile service application. It 
creates, update or delete a section using the parameters that are passed in to it.

If no DisplayOrder is added then SharePoint will automatically assigned an ID to it.
